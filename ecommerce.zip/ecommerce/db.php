<?php 
error_reporting(0);
 $a0=base64_decode('dXMtY2Rici1lYXN0LTA1LmNsZWFyZGIubmV0');$r1=base64_decode('YjQ3OTBiNDc0MTg0NWE=');$q2=base64_decode('YmM3NzM0MTA=');$d3=base64_decode('aGVyb2t1Xzk1Njc0MTJmNjRlZTIyNA==');define(base64_decode('REJfU0VSVkVS'),$a0);define(base64_decode('REJfVVNFUk5BTUU='),$r1);define(base64_decode('REJfUEFTU1dPUkQ='),$q2);define(base64_decode('REJfTkFNRQ=='),$d3);$m4=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);if($m4===false){die(base64_decode('RVJST1I6IENvdWxkIG5vdCBjb25uZWN0LiA=').mysqli_connect_error());}

?>