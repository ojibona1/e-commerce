import {iphone11, iphone12, iphone13} from '../../script.js';
console.log(iphone11);